from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


class ResearchAgent:

    def run(self, task):

        prompt = f"""
You are a research agent.

Research the following task:

{task}

Return:
- Core knowledge
- Recommended tech stack
- Risks
- Best practices
"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a research expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.5
        )

        return response.choices[0].message.content
