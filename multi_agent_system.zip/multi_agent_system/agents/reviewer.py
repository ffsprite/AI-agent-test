from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


class ReviewAgent:

    def run(self, code_result):

        prompt = f"""
You are a review agent.

Review the following code:

{code_result}

Check:
- Bugs
- Security
- Performance
- Readability
"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a strict code reviewer."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2
        )

        return response.choices[0].message.content
