from agents.planner import PlannerAgent
from agents.researcher import ResearchAgent
from agents.coder import CodingAgent
from agents.reviewer import ReviewAgent


planner = PlannerAgent()
researcher = ResearchAgent()
coder = CodingAgent()
reviewer = ReviewAgent()


user_task = "Build an AI chatbot system using FastAPI"

print("=" * 50)
print("User Task")
print(user_task)

print("\n" + "=" * 50)
print("Planner Agent")

plan = planner.run(user_task)
print(plan)

print("\n" + "=" * 50)
print("Research Agent")

research = researcher.run(user_task)
print(research)

print("\n" + "=" * 50)
print("Coding Agent")

code = coder.run(user_task, research)
print(code)

print("\n" + "=" * 50)
print("Review Agent")

review = reviewer.run(code)
print(review)
