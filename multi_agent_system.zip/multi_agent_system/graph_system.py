from typing import TypedDict
from langgraph.graph import StateGraph, END


class AgentState(TypedDict):
    task: str
    plan: str
    research: str
    code: str
    review: str


def planner_node(state):
    state["plan"] = "Planning complete"
    return state


def research_node(state):
    state["research"] = "Research complete"
    return state


def coding_node(state):
    state["code"] = "Code generated"
    return state


def review_node(state):
    state["review"] = "Review complete"
    return state


workflow = StateGraph(AgentState)

workflow.add_node("planner", planner_node)
workflow.add_node("research", research_node)
workflow.add_node("coding", coding_node)
workflow.add_node("review", review_node)

workflow.set_entry_point("planner")

workflow.add_edge("planner", "research")
workflow.add_edge("research", "coding")
workflow.add_edge("coding", "review")
workflow.add_edge("review", END)

app = workflow.compile()

result = app.invoke({
    "task": "Build AI system"
})

print(result)
